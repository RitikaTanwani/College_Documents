import re
import sys
if(sys.argv[1]=='2012'):
 print "equal"
else:
 m=re.match(r'2[^0]\d\d|20[^01]\d|201[^012]|[1-9]\d\d\d\d+|[^012]\d\d\d',sys.argv[1])
#print m.group()
 if not m:
  print "less"
 else:
  print "more"
