import re
import sys
l=re.match(r'(00)*1(11)*$|^(101)0*1*$',sys.argv[1])
#print l.group()
if not l:
	print "not valid"
else:
	print "valid"
