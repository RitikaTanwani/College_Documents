#include<cstdio>
#include<cstdlib>
#include<iostream>
class Stack
{
	private:
		int p;

		int a[100];
	public:
		int size()
		{
			return p+1;
		}

		void push(int x)
		{
			p++;
			a[p]=x;
		}
		int pop()
		{
			a[p]=-1;
			p--;
			if(p==-1)
			 return -1;
			else
		         return a[p];

		}
		Stack()
		{
			int i;
			for(i=0;i<100;i++)
			{
				a[i]=-1;
			}
			p=-1;
		}
		
		void print(int n)
		{
			int i;
			for(i=0;i<n;i++)
			{
				printf("%d ",a[i]);
			}
		}
		int is_empty()
		{
			int i,f=0;
			for(i=0;i<100;i++)
                        {f=0;
				if(a[i]!=-1)
				{
					f=1;
				}
			}
			if(f==1)
				return 0;
			else 
				return 1;
		}
		int find(int x)
		{
			int i,f=0;
			for(i=0;i<100;i++)
			{
				if(x==a[i])
				{f=1;
					break;
				}
			}
			if(f==1)
			 return 1;
			else 
			 return 0;
		}
					


};
int main()
{
	Stack s;
	int i,num,pp;
	/*for(i=0;i<5;i++)
	{

		scanf("%d",&num);
		s.push(num);
	}*/
	printf("empty: %d\n",s.is_empty());
	s.push(40);
	s.push(50);
	//printf("size:%d\n",s.size());
printf("find: %d\n",s.find(50));
printf("find: %d\n",s.find(20));
	printf("%d\n",s.pop());
	s.push(70);
	//s.pop();
	//printf("size:%d\n",s.size());
	printf("empty: %d",s.is_empty());
	s.push(80);
	//s.print(4);
}
