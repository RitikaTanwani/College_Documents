#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
class Mfile
{
	protected://or declare it protected
		FILE *fp;
		char *word;
		char *n;
		char *oldmode;
	public:
		Mfile(char *name,char ch)
		{
			word=new char[100];
			n=new char[100];
			oldmode=new char[2];
                        strcpy(n,name);
			char mode[2];
			sprintf(mode ,"%c",ch);
			strcpy(oldmode,mode);
			fp=fopen(name,mode);

		}
		char *read_word()
		{
			int status = fscanf(fp,"%s",word);
			if(status == EOF)
				strcpy(word, "");
			return word;
		}
		~Mfile()
		{
			delete []word;
			fclose(fp);
		}

		void write_string(char *w)
		{
			if(oldmode[0]=='w'){
				fprintf(fp,"%s",w);
			}
			else
			{
				printf("Cannot write\n");
				return ;
			}
		}


};
class Logfile: public Mfile
{

	public:
		Logfile(char *name):Mfile (name,'a')
		{
//                fopen(name,"a");
		}
		Logfile(char *name,char ch):Mfile (name, ch){}

/*	~Logfile()
		{
			fclose(fp);
                 }*/
	void clear_file()
	{
		fclose(fp);
		fp=fopen(n,"w");
		fclose(fp);
		fp=fopen(n,oldmode);
		//fclose(fp);
	}
	int search_file(char *s)
	{
		fclose(fp);
		fp=fopen(n,"r");

		int f=0;
		while(fscanf(fp,"%s",word)!=EOF)
		{
			if(strcmp(s,word)==0)
			{f=1;
				break;
			}
		}fclose(fp);
		fp=fopen(n,oldmode);
		
		if(f==1)
			return 1;
		else
			return 0;
	}


	        
};
int main(int argc,char *argv[])
{
	char w[100];
	Mfile s(argv[1],argv[2][0]);
/*	if(argv[2][0]=='r')
	{
printf("%s ",s.read_word());
printf("%s ",s.read_word());
printf("%s ",s.read_word());
printf("%s ",s.read_word());
	}
	else
	{
	scanf("%s",w);
s.write_string(w);
	}*/
Logfile s1(argv[1],argv[2][0]);
char tempstr[50];
sprintf(tempstr,"hii");
//printf("%d \n",s1.search_file(tempstr));
s1.write_string(tempstr);
//s1.clear_file();
//printf("%s ",s1.read_word());
}

