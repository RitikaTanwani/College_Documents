#include<stdio.h>

int main(){

	print_arguments(10,'a',"abcdef",20);

	return 0;
}

