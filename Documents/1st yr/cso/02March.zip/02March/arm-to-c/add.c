
int add(int a,int b){
	int x;
	x = a+b;
	return x;
}
