import random
c=0
p=-1
max=0
class tree:
	val=None
	def __init__(self,val):
		self.left=None
		self.right=None
		self.data=val

	def insert(self,val):
		if(random.random()%2==0):
			if(self.left==None):
				new=tree(val)
				self.left=new
			else:
				# self.right=new 
				self.left.insert(val)
		else:
			if(self.right==None):
				new=tree(val)
				self.right=new 
			else:
				self.right.insert(val)
	#	else:
	#		if((random.random)%2==0):
	#			self.left.insert(val)
	#		else:
	#			self.left.insert(val)

	def inorder(self):
		if self.left != None:
			self.left.inorder()
		print self.data
		if self.right != None:
			self.right.inorder()

	def preorder(self):
		print self.data
		if self.left != None:
			self.left.preorder()
		if self.right != None:
			self.right.preorder()

	def postorder(self):
		if self.left != None:
			self.left.postorder()
		if self.right != None:
			self.right.postorder()
		print self.data
   # def find(self,val)
    
	def find(self,val):
		p=0
		if self.data==val:
			print "found"
			p=1
			return p
		else:
			if(p!=1):
				if self.left != None:
					p=self.left.find(val)
		   	if(p!=1):
				if self.right != None:
					p=self.right.find(val)
		return p

	def depth(self):
		global c,max
		if self.left != None:
			self.left.depth()
			c=c+1
		if self.right != None:
			self.right.depth()
           	c=c+1
		if(c>max):
			max=c
			


	    


if __name__ == "__main__":
	num=50
	root=tree(num)
	root.insert(20)
	root.insert(3)
	root.insert(100)
	root.insert(1)
	root.inorder()
	print "------"
	root.preorder()
	print "------"
	root.postorder()
	print root.find(100)

	root.depth()
	print max

