#!/bin/bash
echo enter 1st number
# this is a comment
read num1
echo enter 2nd number
read num2
if[[ $num1 -eq 4]]
then
    echo "value of num1 is 4"
elif [[ $num2 -eq 5]]
then
echo "value of num1 is 5"
fi