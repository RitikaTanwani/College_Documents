#!/bin/bash
echo $1
echo $2
echo $0
# type ./commandline.sh 10 34